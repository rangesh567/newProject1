package com.cart;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping(value="/test3")
public class CartController {
	@Autowired
	RestTemplate rt;
	@Autowired
	CartService cs;
	@PostMapping(value="/postAll")
	public String postAll() {
		String url1="http://localhost:8080/test1/getAll";
		String url2="http://localhost:8081/test2/getAll";
		
		ResponseEntity<List<Customers>> r1=rt.exchange(url1,HttpMethod.GET,null,new ParameterizedTypeReference<List<Customers>>() {});
		List<Customers>x=r1.getBody();
		
		ResponseEntity<List<Product>> r2=rt.exchange(url2,HttpMethod.GET,null,new ParameterizedTypeReference<List<Product>>() {});
		List<Product>y=r2.getBody();
		
		ArrayList<Cart> z=new ArrayList<>();
		for(int i=0;i<=x.size()-1;i++) {
			int netPrice=y.get(i).getPrice()+((y.get(i).getPrice()*y.get(i).getTaxPercentage())/100);
			netPrice=x.get(i).getQuantity()*netPrice; 
			if(x.get(i).getQuantity()>1) {
				netPrice=netPrice-((netPrice*5)/100);
				
			}
			z.add(new Cart(x.get(i).getName(),x.get(i).getGender(),x.get(i).getProductName(),x.get(i).getQuantity(),netPrice));
		}
		return cs.postAll(z);
	}
	@PutMapping(value="/updateCart/id")
	public Cart updateCart(@RequestBody Cart c) {
		return cs.updateCart(c);
	}
	@DeleteMapping(value="/deleteById/{id}")
	public String deleteById(@PathVariable int id) {
		return cs.deleteById(id);
	}
	

}
