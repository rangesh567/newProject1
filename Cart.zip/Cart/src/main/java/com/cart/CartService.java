package com.cart;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {
	@Autowired
	CartDao cd;

	public String postAll(ArrayList<Cart> z) {
		
		return cd.postAll(z);
	}

	public Cart updateCart(Cart c) {
		
		return cd.updateCart(c);
	}

	public String deleteById(int id) {
		
		return cd.deleteById(id);
	}
	

}
