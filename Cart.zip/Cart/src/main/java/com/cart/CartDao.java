package com.cart;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class CartDao {
    @Autowired
    CartRepository cr;
	public String postAll(ArrayList<Cart> z) {
		cr.saveAll(z);
		return "saved";
	}
	public Cart updateCart(Cart c) {
		
		return cr.save(c);
	}
	public String deleteById(int id) {
		cr.deleteById(id);
		return "deleted";
	}

}
