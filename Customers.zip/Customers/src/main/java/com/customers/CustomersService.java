package com.customers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomersService {
	@Autowired
    CustomersDao cd;
	public String postObj(Customers c) {
	   
		return cd.postObj(c);
	}
	public String postAll(List<Customers> c) {
	
		return cd.postAll(c);
	}
	public List<Customers> getAll() {
		
		return cd.getAll();
	}
	public Customers getById(int id) {
		
		return cd.getById(id);
	}
	public Customers updateCustomers(Customers c) {
		
		return cd.updateCustomers(c);
	}
	public String deleteById(int id) {
		
		return cd.deleteById(id);
	}

}
