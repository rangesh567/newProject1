package com.customers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomersDao {
	@Autowired
    CustomersRepository cr;
	public String postObj(Customers c) {
		  cr.save(c);
		return "saved";
		
		
	}
	public String postAll(List<Customers> c) {
		cr.saveAll(c);
		return "saved";
	}
	public List<Customers> getAll() {
		
		return cr.findAll();
	}
	public Customers getById(int id) {
		
		return cr.findById(id).get();
	}
	public Customers updateCustomers(Customers c) {
		
		return cr.save(c);
	}
	public String deleteById(int id) {
		cr.deleteById(id);
		return "deleted";
	}


}
