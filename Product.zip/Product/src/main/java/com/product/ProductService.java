package com.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    @Autowired
    ProductDao pd;
	public String postObj(Product p) {
		
		return pd.postObj(p);
	}
	public String postAll(List<Product> p) {
		
		return pd.postAll(p);
	}
	public List<Product> getAll() {
		
		return pd.getAll();
	}
	public Product getById(int id) {
		
		return pd.getById(id);
	}
	public Product updateProduct(Product p) {

		return pd.updateProduct(p);
	}
	public String deleteById(int id) {
		
		return pd.deleteById(id);
	}

}
