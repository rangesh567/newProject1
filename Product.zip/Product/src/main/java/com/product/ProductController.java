package com.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/test2")
public class ProductController {
	@Autowired
	ProductService ps;
	@PostMapping(value="/postObj")
	public String postObj(@RequestBody Product p) {
		return ps.postObj(p);
	}
	@PostMapping(value="/postAll")
	public String postAll(@RequestBody List<Product> p) {
		return ps.postAll(p);
	}
	@GetMapping(value="/getAll")
	public List<Product> getAll() {
		return ps.getAll();
	}
	@GetMapping(value="/getById/{id}")
	public Product getById(@PathVariable int id) {
		return ps.getById(id);
	}
	@PutMapping(value="/updateProduct/{id}")
	public Product updateProduct(@RequestBody Product p) {
		return ps.updateProduct(p);
	}
	@DeleteMapping(value="/deleteById/{id}")
	public String deleteById(@PathVariable int id) {
		return ps.deleteById(id);
	}

}
