package com.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDao {
	@Autowired
    ProductRepository pr;
	public String postObj(Product p) {
		pr.save(p);
		return "saved";
	}
	public String postAll(List<Product> p) {
	    pr.saveAll(p);
		return "saved";
	}
	public List<Product> getAll() {
		
		return pr.findAll();
	}
	public Product getById(int id) {
		
		return pr.findById(id).get();
	}
	public Product updateProduct(Product p) {
        return pr.save(p);
		
	}
	public String deleteById(int id) {
		pr.deleteById(id);
		return "deleted";
	}

}
